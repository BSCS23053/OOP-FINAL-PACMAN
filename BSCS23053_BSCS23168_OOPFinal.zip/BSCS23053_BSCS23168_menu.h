#pragma once
#include<iostream>
#include"movement_score.h"

using namespace std;

class movement_score;

class menu : public movement_score   
{
protected:
	char start;

public:

	menu() : movement_score() 
	{
		start = NULL;
	}

	menu(char start, char** arr, int size1, int size2, int point, int highscore) : movement_score(arr, size1, size2, point, highscore) 
	{

		this->start = start;
	}

	menu(menu& s) : movement_score(s)  
	{

		start = s.start;
	}

	void set_start(char Start);
	char get_start();
	void output();


};