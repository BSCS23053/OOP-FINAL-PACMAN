#pragma once
#include<iostream>
#include<string>
#include"movement_score.h"
#include"menu.h"

using namespace std;

int main()
{
	int p = 0;
	movement_score* obj;
	movement_score objj;
	menu s;
	obj = &s;



	obj->COLOR();



	cout << "---------------------------------------------------WELCOME TO THE PACMAN BY ABDULLAH AND MIHAB ----------------------------------------------" << endl << endl;
	cout << "PRESS: " << endl;
	cout << "1 To Directly Start the Game" << endl;
	cout << "2. Display Game Instructions and Start" << endl << endl;
	cin >> p;


	if (p == 2)
	{
		objj.output();
		obj->output();

	}

	if (p == 1)
	{

		obj->COLOR2();
		obj->output();
	}


	return 0;
}