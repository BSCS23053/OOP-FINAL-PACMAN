#pragma once
#ifndef MYGRAPHICS_H_
#define MYGRAPHICS_H_

#include <windows.h>

#define BROWN			6
#define LIGHTRED		12
#define LIGHTGREEN		10
#define LIGHTMAGENTA	13
#define PURPLE	        16






const int WHITE = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY;
const int RED = FOREGROUND_RED | FOREGROUND_INTENSITY;
const int BLUE = FOREGROUND_BLUE | FOREGROUND_INTENSITY;

const int DARK_BLUE = FOREGROUND_BLUE;
#define GREEN			2
const unsigned short BRIGHT_BLUE = FOREGROUND_BLUE | FOREGROUND_INTENSITY;
const int CYAN = FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY;
const int MAGENTA = FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY;
const int YELLOW = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY;
const int BLACK = 0;


inline void drawLine(int x1, int y1, int x2, int y2, int colour); 
inline void drawLine(int x1, int y1, int x2, int y2, int r, int g, int b); 
inline void drawRectangle(int x1, int y1, int x2, int y2, int R, int G, int B); 
inline void drawRectangle(int x1, int y1, int x2, int y2, int R, int G, int B, int FR, int FG, int FB); 
inline void drawEllipse(int x1, int y1, int x2, int y2, int R, int G, int B); 
inline void drawEllipse(int x1, int y1, int x2, int y2, int R, int G, int B, int FR, int FG, int FB); 
inline void cls(); 
inline void delay(int ms); 
inline char getKey(); 
inline void getWindowDimensions(int& width, int& height); 
inline void getConsoleWindowDimensions(int& width, int& height); 
inline void gotoxy(int x, int y); 
inline void showConsoleCursor(bool showFlag); 




inline void SetTextColor(int color)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}



void drawLine(int x1, int y1, int x2, int y2, int colour)
{
	drawLine(x1, y1, x2, y2, colour, colour, colour);
}

void drawLine(int x1, int y1, int x2, int y2, int R, int G, int B) //use three 3 integers if you want colored lines.
{
	HWND consoleHandle = GetConsoleWindow();
	HDC deviceContext = GetDC(consoleHandle);

	
	HPEN pen = CreatePen(PS_SOLID, 4, RGB(R, G, B)); 
	SelectObject(deviceContext, pen);
	MoveToEx(deviceContext, x1, y1, NULL);
	LineTo(deviceContext, x2, y2);
	DeleteObject(pen);
	ReleaseDC(consoleHandle, deviceContext);
}

void drawRectangle(int x1, int y1, int x2, int y2, int R, int G, int B)
{
	drawRectangle(x1, y1, x2, y2, R, G, B, 0, 0, 0);
}

void drawRectangle(int x1, int y1, int x2, int y2, int R, int G, int B, int FR, int FG, int FB)
{
	HWND consoleHandle = GetConsoleWindow();
	HDC deviceContext = GetDC(consoleHandle);

	
	HPEN pen = CreatePen(PS_SOLID, 2, RGB(R, G, B));
	SelectObject(deviceContext, pen);
	HBRUSH brush = CreateSolidBrush(RGB(FR, FG, FB));
	SelectObject(deviceContext, brush);
	Rectangle(deviceContext, x1, y1, x2, y2);
	DeleteObject(pen);
	DeleteObject(brush);
	ReleaseDC(consoleHandle, deviceContext);

}

void drawEllipse(int x1, int y1, int x2, int y2, int R, int G, int B)
{
	drawEllipse(x1, y1, x2, y2, R, G, B, 0, 0, 0);
}

void drawEllipse(int x1, int y1, int x2, int y2, int R, int G, int B, int FR, int FG, int FB)
{
	HWND consoleHandle = GetConsoleWindow();
	HDC deviceContext = GetDC(consoleHandle);

	
	HPEN pen = CreatePen(PS_SOLID, 3, RGB(R, G, B));
	SelectObject(deviceContext, pen);
	HBRUSH brush = CreateSolidBrush(RGB(FR, FG, FB)); 
	SelectObject(deviceContext, brush);
	Ellipse(deviceContext, x1, y1, x2, y2);
	DeleteObject(pen);
	DeleteObject(brush);
	ReleaseDC(consoleHandle, deviceContext);

}

void cls()
{
	COORD coordScreen = { 0, 0 };    
	DWORD cCharsWritten;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	DWORD dwConSize;

	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);

	if (!GetConsoleScreenBufferInfo(consoleHandle, &csbi))
	{
		return;
	}

	dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

	FillConsoleOutputCharacter(consoleHandle,        
		(TCHAR)' ',         
		dwConSize,          
		coordScreen,        
		&cCharsWritten);    

}

void delay(int ms)
{

	Sleep(ms);
}

char getKey()
{
	HANDLE consoleHandle = GetStdHandle(STD_INPUT_HANDLE);
	DWORD size = 1;
	INPUT_RECORD input[1];
	DWORD events = 0;
	char key = '\0';

	if (PeekConsoleInput(consoleHandle, input, size, &events)) {
		if (input[0].EventType == KEY_EVENT) {
			key = input[0].Event.KeyEvent.uChar.AsciiChar;
			FlushConsoleInputBuffer(consoleHandle);
			return key;
		}
	}

	return key; 
}

void getWindowDimensions(int& width, int& height)
{
	HWND consoleHandle = GetConsoleWindow();
	RECT rc;
	GetClientRect(consoleHandle, &rc);
	width = rc.right;
	height = rc.bottom;
}

void getConsoleWindowDimensions(int& width, int& height)
{
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;

	if (!GetConsoleScreenBufferInfo(consoleHandle, &csbi))
	{
		return;
	}

	width = csbi.srWindow.Right;
	height = csbi.srWindow.Bottom;
}

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}


void showConsoleCursor(bool flag)
{
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO cursorInfo;

	GetConsoleCursorInfo(consoleHandle, &cursorInfo);
	cursorInfo.bVisible = flag; 
	SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}

#endif 